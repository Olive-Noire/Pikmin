import pygame

class InputBox(pygame.sprite.Sprite):

    def __init__(self, 
                 x, y, w, h, 
                 text='',
                 col_inactive = pygame.Color('blue'),
                 col_active = pygame.Color('green')):
        
        pygame.sprite.Sprite.__init__(self)
        self.COLOR_INACTIVE = col_inactive
        self.COLOR_ACTIVE = col_active
        self.FONT = pygame.font.Font(None, 26)
        self.rect = pygame.Rect(x, y, w, h)
        self.color = self.COLOR_INACTIVE
        self.text = text
        self.txt_surface = self.FONT.render(text, True, self.color)
        self.active = False
        self.simulation = False

    def draw(self, screen):
        screen.blit(self.txt_surface, (self.rect.x+5, self.rect.y+5))
        pygame.draw.rect(screen, self.color, self.rect, 2)

    def mouse_event(self, event):
        if self.rect.collidepoint(event.pos):
            self.active = not self.active
        else:
            self.active = False
        self.color = self.COLOR_ACTIVE if self.active else self.COLOR_INACTIVE

    def keyboard_event(self, event):
        if event.key == pygame.K_q:
            self.simulation = False
        elif event.key == pygame.K_s:
            self.simulation = True
        elif self.active and not self.simulation:
            if event.key == pygame.K_RETURN:
                self.text = ''
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                self.text += event.unicode
            self.txt_surface = self.FONT.render(self.text, True, self.color)
        