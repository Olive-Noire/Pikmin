import pygame, sys
from sprite_classes import Pikman
from input_classes import InputBox

pygame.init()
MILLE = 1000
FPS = 30


screen = pygame.display.set_mode((640, 480))
clock = pygame.time.Clock()
pikmin = pygame.image.load('sprites/pikman2.png').convert()
background = pygame.image.load('sprites/tkt.jpeg').convert()
screen.blit(background, (0, 0))


dx = InputBox(400, 100, 70, 30)
dy = InputBox(400, 200, 70, 30)
ax = InputBox(500, 100, 70, 30)
ay = InputBox(500, 200, 70, 30)
inputs = [dx, dy, ax, ay]

pikmin = Pikman(pikmin, 128, dx, dy, ax, ay)
groupe = pygame.sprite.Group()
groupe.add(pikmin)

run = True
sim = False
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            for i in inputs:
                i.mouse_event(event)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                run = False
            for i in inputs:
                i.keyboard_event(event)
            groupe.update(event)

    screen.blit(background, (0, 0))
    groupe.update(None)
    groupe.draw(screen)
    for i in inputs:
        i.draw(screen)
        
    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()
