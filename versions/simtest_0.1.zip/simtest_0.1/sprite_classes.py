import pygame

class Pikman(pygame.sprite.Sprite):
    
    def __init__(self, image:pygame.Surface, height, dx_input, dy_input, ax_input, ay_input):
        pygame.sprite.Sprite.__init__(self)
        self.dx_input = dx_input
        self.dy_input = dy_input
        self.ax_input = ax_input
        self.ay_input = ay_input
        self.image = image
        self.rect = self.image.get_rect()
        self.fl_pos = [0.0, 0.0]
        self.spd = [0.0, 0.0]
        self.acc = [0.0, 0.0]
        self.simulation = False

    def update(self, event=None):
        if event is None:
            if self.simulation:
                self.spd = [self.spd[0] + self.acc[0],
                            self.spd[1] + self.acc[1]]
                self.fl_pos = [self.fl_pos[0] + self.spd[0],
                               self.fl_pos[1] + self.spd[1]]
                self.rect.topleft = (int(self.fl_pos[0]), int(self.fl_pos[1]))

        else:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    self.simulation = False
                if event.key == pygame.K_s:
                    self.simulation = True
                    try:
                        self.spd[0] = float(self.dx_input.text)
                    except ValueError:
                        self.spd[0] = 0.0
                    try:
                        self.spd[1] = float(self.dy_input.text)
                    except ValueError:
                        self.spd[1] = 0.0
                    try:
                        self.acc[0] = float(self.ax_input.text)
                    except ValueError:
                        self.acc[0] = 0.0
                    try:
                        self.acc[1] = float(self.ay_input.text)
                    except ValueError:
                        self.acc[1] = 0.0
                        
                if event.key == pygame.K_d:
                    self.spd = [0.0, 0.0]
                    self.fl_pos = [0.0, 0.0]
                    self.rect.topleft = [0.0, 0.0]
                    